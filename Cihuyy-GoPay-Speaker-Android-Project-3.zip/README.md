# Cihuyy GoPay Speaker

Aplikasi Android sederhana yang membaca notifikasi GoPay Merchant lalu mengucapkan:

> Cihuyy GoPay masuk lima belas ribu rupiah nih

## Cara kerja

GoPay Merchant
→ notifikasi pembayaran
→ NotificationListenerService
→ ambil nominal Rp...
→ Text-to-Speech Android
→ suara keluar dari HP.

Aplikasi menargetkan package GoPay Merchant resmi:
`com.gojek.gopaymerchant`

GoPay Merchant saat ini tercantum di Google Play dengan package tersebut.

## Cara menjalankan

1. Buka project ini di Android Studio.
2. Gunakan JDK 17.
3. Biarkan Android Studio mengunduh Gradle/Android Gradle Plugin jika diminta.
4. Pilih `app` lalu Run.
5. Di HP, buka aplikasi **Cihuyy GoPay Speaker**.
6. Tekan **Aktifkan akses notifikasi**.
7. Aktifkan akses untuk Cihuyy GoPay Speaker.
8. Pastikan notifikasi GoPay Merchant aktif.
9. Tekan **Tes suara** untuk memastikan Text-to-Speech bekerja.
10. Lakukan transaksi QRIS kecil untuk pengujian.

## Catatan penting

Aplikasi ini tidak mengakses saldo, PIN, OTP, rekening, atau login GoPay.
Aplikasi hanya membaca teks notifikasi yang diberikan Android melalui NotificationListenerService.

Format notifikasi GoPay dapat berubah sewaktu-waktu. Jika nominal tidak terbaca, contoh teks notifikasi asli diperlukan untuk menyesuaikan parser.

Jangan gunakan hasil suara sebagai satu-satunya bukti pembayaran. Tetap cek transaksi di GoPay Merchant bila ada keraguan.

## Build APK

Di Android Studio:
Build → Build Bundle(s) / APK(s) → Build APK(s)

Atau dari terminal project:
`./gradlew assembleDebug`

APK debug akan berada di:
`app/build/outputs/apk/debug/app-debug.apk`
