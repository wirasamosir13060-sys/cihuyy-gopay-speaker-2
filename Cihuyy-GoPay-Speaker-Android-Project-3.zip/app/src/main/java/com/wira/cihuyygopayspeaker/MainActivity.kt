package com.wira.cihuyygopayspeaker

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : android.app.Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        tts = TextToSpeech(this, this)

        val title = TextView(this).apply {
            text = "🔊 Cihuyy GoPay Speaker"
            textSize = 25f
            setPadding(32, 40, 32, 20)
        }

        val info = TextView(this).apply {
            text = """
                HP ini akan membaca notifikasi pembayaran GoPay Merchant.

                Contoh:
                "Cihuyy GoPay masuk lima belas ribu rupiah nih"

                1. Aktifkan akses Notifikasi untuk aplikasi ini.
                2. Pastikan notifikasi GoPay Merchant aktif.
                3. Coba tombol tes suara.
            """.trimIndent()
            textSize = 17f
            setPadding(32, 10, 32, 30)
        }

        val settingsButton = Button(this).apply {
            text = "⚙️ Aktifkan akses notifikasi"
            setOnClickListener {
                startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
            }
        }

        val testButton = Button(this).apply {
            text = "🔊 Tes suara"
            setOnClickListener {
                speak("Cihuyy GoPay masuk lima belas ribu rupiah nih")
            }
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
            addView(title)
            addView(info)
            addView(settingsButton)
            addView(testButton)
        }

        setContentView(layout)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("id", "ID")
            tts?.setSpeechRate(1.0f)
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "test-payment")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
