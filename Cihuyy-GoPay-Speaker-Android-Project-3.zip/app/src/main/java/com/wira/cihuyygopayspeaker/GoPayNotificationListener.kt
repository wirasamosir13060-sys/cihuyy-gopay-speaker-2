package com.wira.cihuyygopayspeaker

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import java.text.NumberFormat
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

class GoPayNotificationListener : NotificationListenerService() {

    private var tts: TextToSpeech? = null
    private val spoken = ConcurrentHashMap.newKeySet<String>()

    companion object {
        private const val GOPAY_PACKAGE = "com.gojek.gopaymerchant"

        // Menangkap Rp15.000, Rp 15.000, Rp15,000, dan variasi serupa.
        private val MONEY_REGEX =
            Regex("""(?i)\bRp\s*([0-9][0-9.,]*)""")
    }

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("id", "ID")
                tts?.setSpeechRate(1.0f)
            }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != GOPAY_PACKAGE) return

        val n = sbn.notification ?: return

        // Ambil semua bagian teks notifikasi yang umum dipakai Android.
        val extras = n.extras
        val title = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras?.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()

        val combined = listOf(title, text, bigText)
            .filter { it.isNotBlank() }
            .joinToString(" ")

        // Hanya bicara jika benar-benar ada nominal rupiah.
        val amountRaw = MONEY_REGEX.find(combined)?.groupValues?.getOrNull(1) ?: return

        // Hindari membaca notifikasi yang sama berulang kali.
        val uniqueKey = "${sbn.key}|$combined"
        if (!spoken.add(uniqueKey)) return

        val amount = parseIndonesianAmount(amountRaw) ?: return

        val spokenAmount = amountToIndonesian(amount)
        val message = "Cihuyy GoPay masuk $spokenAmount rupiah nih"

        tts?.speak(
            message,
            TextToSpeech.QUEUE_ADD,
            null,
            "payment-${sbn.id}-${System.currentTimeMillis()}"
        )
    }

    private fun parseIndonesianAmount(raw: String): Long? {
        // GoPay/Indonesia umumnya menggunakan titik sebagai pemisah ribuan.
        // Jika ada koma dan titik, pertahankan hanya digit agar aman untuk nominal rupiah.
        val digits = raw.filter { it.isDigit() }
        return digits.toLongOrNull()
    }

    private fun amountToIndonesian(value: Long): String {
        if (value == 0L) return "nol"

        val units = arrayOf(
            "", "ribu", "juta", "miliar", "triliun"
        )

        fun belowThousand(n: Long): String {
            val ones = arrayOf(
                "nol", "satu", "dua", "tiga", "empat",
                "lima", "enam", "tujuh", "delapan", "sembilan"
            )
            return when {
                n < 10 -> ones[n.toInt()]
                n < 20 -> if (n == 10L) "sepuluh" else ones[(n - 10).toInt()] + " belas"
                n < 100 -> {
                    val tens = n / 10
                    val rest = n % 10
                    "${ones[tens.toInt()]} puluh" + if (rest > 0) " ${ones[rest.toInt()]}" else ""
                }
                else -> {
                    val hundreds = n / 100
                    val rest = n % 100
                    val h = if (hundreds == 1L) "seratus" else "${ones[hundreds.toInt()]} ratus"
                    if (rest > 0) "$h ${belowThousand(rest)}" else h
                }
            }
        }

        fun convert(n: Long, unitIndex: Int): String {
            if (n == 0L) return ""
            if (n < 1000L) {
                return "${belowThousand(n)}${if (unitIndex > 0) " ${units[unitIndex]}" else ""}"
            }

            val high = n / 1000L
            val low = n % 1000L

            val highText =
                if (high == 1L && unitIndex == 1) "seribu"
                else "${convert(high, unitIndex + 1)}"

            val lowText = if (low > 0) " ${belowThousand(low)}" else ""
            return highText + if (unitIndex >= 0) " ${units[unitIndex]}" else "" + lowText
        }

        // Versi rekursif di atas lebih mudah dibaca untuk nominal kecil,
        // tetapi untuk menghindari format yang salah pada unit besar,
        // gunakan pemecahan 3 digit berikut.
        val groups = mutableListOf<Long>()
        var n = value
        while (n > 0) {
            groups.add(n % 1000)
            n /= 1000
        }

        val result = StringBuilder()
        for (i in groups.indices.reversed()) {
            val g = groups[i]
            if (g == 0L) continue

            if (result.isNotEmpty()) result.append(" ")

            if (i == 1 && g == 1L) {
                result.append("seribu")
            } else {
                result.append(belowThousand(g))
                if (i > 0) result.append(" ").append(units[i])
            }
        }
        return result.toString()
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        tts?.stop()
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
