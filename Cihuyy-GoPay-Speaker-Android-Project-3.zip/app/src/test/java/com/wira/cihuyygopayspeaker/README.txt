Parser nominal dan TTS dapat dikembangkan lebih lanjut setelah melihat format notifikasi GoPay Merchant pada HP pengguna.
